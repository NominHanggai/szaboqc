# Modern Quantum Chemistry
Attila *Modern Quantum Chemistry: Introduction to Advanced Electronic Structure Theory* 中文翻译

重新绘制所有插图
